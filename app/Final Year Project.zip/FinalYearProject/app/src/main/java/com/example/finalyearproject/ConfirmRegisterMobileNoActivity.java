package com.example.finalyearproject;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class ConfirmRegisterMobileNoActivity extends AppCompatActivity {

    EditText etConfirmRegisterMobileNo;
    AppCompatButton btnVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_register_mobile_no);

        etConfirmRegisterMobileNo = findViewById(R.id.etConfirmRegisterMobileNO);
        btnVerify = findViewById(R.id.acbtnConfirmRegisterMobileNoVerify);

        btnVerify.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {
                if(etConfirmRegisterMobileNo.getText().toString().isEmpty())
                {
                    etConfirmRegisterMobileNo.setError("Please Enter Mobile Number");
                }
                else if(etConfirmRegisterMobileNo.getText().toString().length() != 10)
                {
                    etConfirmRegisterMobileNo.setError("Please Enter Valid Mobile Number");
                }
                else
                {

                }
            }
        });
    }
}